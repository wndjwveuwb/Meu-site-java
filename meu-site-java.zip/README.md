# Site Java no Render

Este é um exemplo simples de site Java utilizando Sockets e hospedado na plataforma **Render**.

## Estrutura do Projeto
```
meu-site-java/
├── src/
│   └── Main.java
├── Procfile
└── README.md
```

## Como executar localmente
1. Compile e execute:
   ```bash
   javac src/Main.java
   java -cp src Main
   ```

2. Acesse no navegador: http://localhost:8080

## Publicação no Render
1. Faça upload do projeto para o GitHub.
2. Conecte sua conta no [https://render.com](https://render.com).
3. Crie um novo serviço web com o comando de inicialização:
   ```bash
   java -cp src Main
   ```
4. O Render gerará um link público do tipo:
   https://seusite.onrender.com
