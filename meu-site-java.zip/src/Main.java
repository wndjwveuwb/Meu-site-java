import java.io.*;
import java.net.*;

public class Main {
    public static void main(String[] args) throws IOException {
        int port = 8080;
        ServerSocket server = new ServerSocket(port);
        System.out.println("Servidor rodando na porta " + port);

        while (true) {
            Socket client = server.accept();
            BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
            PrintWriter out = new PrintWriter(client.getOutputStream(), true);

            String request = in.readLine();
            if (request == null) continue;

            String response = """
                HTTP/1.1 200 OK
                Content-Type: text/html; charset=UTF-8

                <html>
                    <head><title>Site Java no Render</title></head>
                    <body>
                        <h1>Olá, mundo! 🚀</h1>
                        <p>Servidor Java hospedado no Render com sucesso!</p>
                    </body>
                </html>
            """;

            out.println(response);
            client.close();
        }
    }
}
